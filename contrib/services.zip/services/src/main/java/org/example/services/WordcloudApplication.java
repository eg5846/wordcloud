package org.example.services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordcloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(WordcloudApplication.class, args);
	}

}
